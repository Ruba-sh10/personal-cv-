
package hotelmanagementsystem;

import java.io.*;
import javax.swing.JOptionPane;

public class Hotel implements Serializable {
    private String hotelName; 
    private String location; 
    private Room[] rooms; 
    private int numberOfReservations; 
    private Reservation[] reservations; 
    
    // Constructor method
    public Hotel(String hotelName, String location, Room[] rooms) {
        this.hotelName = hotelName;
        this.location = location;
        this.rooms = rooms;
        reservations = new Reservation[100];
        numberOfReservations = 0;
    }
    
    // Method to search for a room by its number
    public Room searchRoom(int roomNumber) {
        for (int i = 0; i < rooms.length; i++) 
            if (rooms[i] != null) 
                if (rooms[i].getRoomNumber() == roomNumber) 
                    return rooms[i];
        return null;
    }
    
    // Method to display information about all rooms
    public void displayRooms() {
        
        for (int i = 0; i < rooms.length; i++) 
            if (rooms[i] != null) 
                System.out.println(rooms[i].toString());  

}



    public Reservation[] displayReservations() {
        
        if(numberOfReservations==0){
            return null ;
        
        }
        else {
        
        Reservation arr[] = new Reservation[numberOfReservations]; 
        for(int i = 0 ; i < numberOfReservations ; i++)  {
         arr[i] = reservations[i]; }
        return arr;
        } 
}
              
        
 
   


    
    // Method to add a reservation
    public boolean addReservation(Reservation res) {
        Room room = res.getRoom();
        if (!room.isCheckedIn()) {
            room.setGuest(res.getGuest());
            reservations[numberOfReservations++] = res;
            System.out.println("Reservation successful. Reservation ID: " + res.getReservationID());
            return true;
        } else {
            System.out.println("Room is already occupied.");
            return false;
        }
    }
    
    // Method to cancel a reservation
    public void cancelReservation(int reservationID) {
        for (int i = 0; i < numberOfReservations; i++) {
            if (reservations[i].getReservationID() == reservationID) {
                reservations[i].getRoom().checkOut();
                for (int j = i; j < numberOfReservations - 1; j++) 
                    reservations[j] = reservations[j + 1];
                reservations[--numberOfReservations] = null;
                System.out.println("Reservation canceled.");
                return;
            } 
        } 
        System.out.println("Reservation not found.");
    }
    
    
    // Method to search for a reservation by its ID
    public Reservation searchReservation(int reservationID) {
        for (int i = 0; i < numberOfReservations; i++) 
            if (reservations[i].getReservationID() == reservationID) 
                return reservations[i];
        return null; // Reservation not found
    } 
    
    // Method to get the hotel name
    public String getHotelName(){
        return hotelName;
    }
    
    
    public void save(String fileName) {
        try {
             File out = new File(fileName);
             
             if (out.exists()){
                 int num = JOptionPane.showConfirmDialog( null, "this file is already saved, "
                         + "do you want to continue?", "Notafication", JOptionPane.YES_NO_OPTION);
                 if (num == JOptionPane.NO_OPTION)
                     return;
             }
             
             FileOutputStream fos = new FileOutputStream(out);
             ObjectOutputStream oos = new ObjectOutputStream(fos);

            oos.writeInt(numberOfReservations);
            for (int i = 0; i < numberOfReservations; i++) {
                oos.writeObject(reservations[i]);
            }
            
            oos.close();
            JOptionPane.showMessageDialog( null, "Hotel information saved successfully to " + fileName);
        } catch (IOException e) {
            JOptionPane.showMessageDialog( null, "Error in saving hotel information: " + e.toString());
        }
    }
    
    public boolean load(String fileName) {
        try {
            File file = new File(fileName);
            if (! file.exists()){
                return false;
            }
            FileInputStream fis = new FileInputStream(file);
            ObjectInputStream ois = new ObjectInputStream(fis);

            int size = ois.readInt();
            
            this.numberOfReservations = ois.readInt();
            this.reservations = new Reservation[100]; // Initialize reservations array
            
            for (int i = 0; i < numberOfReservations; i++) {
                this.reservations[i] = (Reservation) ois.readObject();
            }

            ois.close();
            JOptionPane.showMessageDialog( null,"Hotel information loaded successfully from " + fileName);
        } catch (ClassNotFoundException e) {
            JOptionPane.showMessageDialog( null, "Error while reading object: " + e.toString());
        } catch (IOException e) {
            JOptionPane.showMessageDialog( null,"Error while loading file " + e.toString());
        }
        return true;
    }


}



