package hotelmanagementsystem;

import java.util.Scanner;

public class HotelManagementSystemPh2 {
    static Scanner input = new Scanner(System.in);
    static NewJFrame mainFrame = new NewJFrame();
    public static void main(String[] args) {
       
        
        mainFrame.setVisible(true);
        
        /**
        // Initialize an array of rooms
        Room[] rooms = new Room[30];
        
        // Initialize some rooms with different types
        rooms[0] = new LuxuryRoom(101, 1000, true, 2, "King");
        rooms[1] = new LuxuryRoom(201, 1000, false, 1, "Queen"); 
        rooms[2] = new LuxuryRoom(301, 1000, false, 4, "Queen");
        rooms[3] = new StandardRoom(302, 600, true, 3);
        rooms[4] = new StandardRoom(306, 600, false, 2);
        
        // Create a hotel object
        Hotel hotel = new Hotel("My Hotel", "My Location", rooms); 
        
        int choice;
        do {
            System.out.println("Welcome to " + hotel.getHotelName());
            System.out.println("1. Display available rooms");
            System.out.println("2. Make a reservation");
            System.out.println("3. Cancel a reservation");
            System.out.println("4. Search for a reservation");
            System.out.println("5. Exit");
            System.out.println("6. Save");
            System.out.print("Enter your choice: ");
            
            choice = input.nextInt();
            
            switch (choice) {
                case 1:
                    hotel.displayRooms();
                    break;
                    
                case 2:
                    System.out.print("Enter number of nights: ");
                    int numOfNights = input.nextInt();
    
                    // Guest information
                    System.out.print("Enter guest information: name and phone number ");
                    String name = input.next();
                    int telNum = input.nextInt();
                    Guest guest = new Guest(name, telNum);
    
                    boolean validRoom = false;
                    int roomNumber;
                    Room room;
                    while (!validRoom) {
                        System.out.print("Enter room number: ");
                        roomNumber = input.nextInt();
    
                        room = hotel.searchRoom(roomNumber);
    
                        // Check if the room is available
                        if (room != null && !room.isCheckedIn()) {
                            validRoom = true;
    
                            // Create a Reservation object based on the reservation details
                            Reservation reservation = new Reservation(numOfNights, room, guest);
    
                            // Add the reservation to the hotel
                            hotel.addReservation(reservation);
                        } else {
                            System.out.println("Invalid room number or the room is already occupied. Please try again.");
                        }
                    }
                    break;
                  
                case 3:
                    System.out.print("Enter reservation ID: ");
                    int cancellationID = input.nextInt();
    
                    // Cancel the reservation with the specified ID
                    hotel.cancelReservation(cancellationID);
                    break;
                    
                case 4:
                    System.out.print("Enter reservation ID: ");
                    int searchID = input.nextInt();
    
                    // Search for the reservation
                    Reservation searchedReservation = hotel.searchReservation(searchID);
    
                    // Display the reservation if found
                    if (searchedReservation != null) {
                        System.out.println("Reservation found:");
                        searchedReservation.toString();
                    } else {
                        System.out.println("Reservation not found.");
                    }
                    break;
    
                case 5:
                    System.out.println("Thank you for using our hotel reservation system. Goodbye!");
                    break;
                    
                
                case 6:
                    // Save hotel information
                    hotel.save("hotelInfo.ser");
                    break;

                case 7:
                    // Load hotel information
                    System.out.println("Enter the name of the file you want to load");
                    String file =input.next();
                    hotel.load(file);
                    break;
            default:
                    System.out.println("Invalid choice. Please try again.");
                    break; 
            
            }
        } while (choice != 7);*/

    }
    
}