
package hotelmanagementsystem;

public class StandardRoom extends Room {
    private boolean isSmokingAllowed; 
    private int maxOccupancy; 
    
    // Constructor method
    public StandardRoom(int roomNum, double basePrice, boolean isSmokingAllowed, int maxOccupancy) {
        super(roomNum, basePrice);
        this.isSmokingAllowed = isSmokingAllowed;
        this.maxOccupancy = maxOccupancy;
    }
    
    // Method to check if smoking is allowed in the room
    public boolean isSmokingAllowed() {
        return isSmokingAllowed;
    }
    
    // Method to get the maximum occupancy of the room
    public int getMaxOccupancy() {
        return maxOccupancy;
    }
    
    // Method to calculate the total price of staying in the standard room
    public double calculatePrice() {
        double extraCharge = 0.0;
        
        if (maxOccupancy > 2) 
            extraCharge += (maxOccupancy - 2) * 25; // Assuming $25 per extra occupant
        
        return basePrice + extraCharge;
    }
    
    // Method to display information about the standard room
    public String toString() {
        String superClassInfo = super.toString(); // Call the toString method of the superclass
        String smokingAllowedInfo = isSmokingAllowed() ? "Smoking is allowed in this room." : "Smoking is not allowed in this room.";
        String info = superClassInfo +
                  smokingAllowedInfo + "\n" +
                  "Max Occupancy: " + maxOccupancy + "\n" +
                  "Price: " + calculatePrice() + "\n";
    return info;
}

}
