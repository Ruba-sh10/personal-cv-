
package hotelmanagementsystem;
import java.io.*;
public class Reservation implements Serializable {
    private int reservationID; 
    private int numOfNights; 
    private Room room; 
    private Guest guest;
    private static int num;
    
    // Constructor method
    public Reservation(int numOfNights, Room room, Guest guest)  {
        this.numOfNights = numOfNights;
        this.room = room;
        this.guest = guest;
        reservationID = ++num;
    }
    
    // Method to calculate the total price of the reservation
    public double calculateTotalPrice() {
        return numOfNights * room.calculatePrice();
    }
    
    // Method to get the reserved room
    public Room getRoom() {
        return room;
    }

    // Method to get the number of nights for the reservation
    public int getNumOfNights() {
        return numOfNights;
    }

    
    // Method to get the guest making the reservation
    public Guest getGuest(){
        return guest;
    }
    
    // Method to get the reservation ID
    public int getReservationID(){
        return reservationID;
    }
    
    // Method to display reservation information
    public String toString() {
        String guestInfo = guest.toString(); // Assuming guest has a toString method
        String info = guestInfo +
                  "Reservation ID: " + reservationID + "\n Room: " + room.getRoomNumber() + "\nTotal Price: " + String.format("%.2f", calculateTotalPrice()) + "\n";
        return info;
    }
}
