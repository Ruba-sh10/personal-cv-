
package hotelmanagementsystem;
import java.io.*;


public abstract class Room implements Serializable{
   protected int roomNumber;
    protected Guest guest;
    protected double basePrice;

    // Constructor
    public Room(int roomNum, double basePrice) {
        roomNumber = roomNum;
        this.basePrice = basePrice;
        guest = null;
    }

    // Method to check if room is checked in
    public boolean isCheckedIn() {
        return (guest != null);
    }

    // Method to check out guest
    public void checkOut() {
        guest = null;
    }

    // Method to set guest for the room
    public void setGuest(Guest guest) {
        this.guest = guest;
    }

    // Abstract method to calculate room price
    public abstract double calculatePrice();

    // Method to display room information
   @Override
   public String toString() {
    String occupancyStatus = isCheckedIn() ? "Room is Occupied." : "Room is not Occupied.";
    String info = "\n*** Room Information ***\n" +
                  "Room Number: " + roomNumber + "\n" +
                  occupancyStatus + "\n";
    return info;
}
    
    // Getter for room number
    public int getRoomNumber() {
        return roomNumber;
    }


    
 
}
