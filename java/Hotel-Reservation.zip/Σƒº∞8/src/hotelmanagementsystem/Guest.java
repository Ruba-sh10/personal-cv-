
package hotelmanagementsystem;

import java.io.*;
public class Guest implements Serializable{
     private String Name;
    private int TelNum;

    // Constructor
    public Guest(String Name, int TelNum) {
        this.Name = Name;
        this.TelNum = TelNum;
    }

    // Method to display guest information
    public String toString() {
         return "Name: " + Name + ", Telephone Number: " + TelNum;
    }

    // Getter for guest name
    public String getName() {
        return Name;
    }
}
