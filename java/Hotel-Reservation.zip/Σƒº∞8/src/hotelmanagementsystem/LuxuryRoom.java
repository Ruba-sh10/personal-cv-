
package hotelmanagementsystem;


public class LuxuryRoom extends Room  {
     private boolean hasHotTub;
    private int numOfBeds; 
    private String bedType; 
    
    // Constructor method
    public LuxuryRoom (int roomNum,double basePrice,  boolean hasHotTub, int numOfBeds, String bedType){
        super(roomNum,basePrice);
        this.hasHotTub = hasHotTub;
        this.numOfBeds = numOfBeds;
        this.bedType= bedType;
    }
    
    // Method to calculate the total price of staying in the luxury room
    public double calculatePrice(){
        double bedPrice = 1.0;
        
        switch (numOfBeds){
            case 1:
                bedPrice += 0;
                break;
            case 2:
                bedPrice += 0.2;
                break;
            case 3:
                bedPrice += 0.3;
                break;
            case 4: 
                bedPrice += 0.4;
                break;
            default:
                System.out.println("Unavailable number of beds");
                break;
        }
        
        if (bedType.equals("Queen"))
            bedPrice += 0.2;
        else if (bedType.equals("King"))
            bedPrice += 0.3;
        
        return ( basePrice + bedPrice);
    }
    
    // Method to display luxury room information
   
     @Override
    public String toString(){
         String hotTubInfo = hasHotTub ? "The room has a hot tub" : "The room does not have a hot tub";
    String info = super.toString() + "\n" +
                  hotTubInfo + "\n" +
                  "Number of Beds: " + numOfBeds + "\n" +
                  "Bed Type: " + bedType + "\n" +
                  "Price: " + calculatePrice();
    return info;
    }

}
