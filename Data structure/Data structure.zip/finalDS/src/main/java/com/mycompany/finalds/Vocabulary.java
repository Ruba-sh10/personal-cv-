/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.finalds;

/**
 *
 * @author 1234
 */
public class Vocabulary {
    public String word;

    public Vocabulary() {
        word = "";
    }

    public Vocabulary(String word) {
        this.word = word;
    }

    @Override
    public String toString() {
        return word;
    }
    
    
    
}